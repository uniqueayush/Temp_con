package com.example.temperatureconvertar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button button,button2;
    private TextView result;
    private EditText enterTeam;
    double result0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button =findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        result=this.findViewById(R.id.result);
        enterTeam=this.findViewById(R.id.enterTeam);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double temp = Double.parseDouble(enterTeam.getText().toString());
                result0 = (temp *1.8)+32;
                result.setText(String.valueOf(result0));
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double temp = Double.parseDouble(enterTeam.getText().toString());
                result0 = (temp -32)/1.8;
                result.setText(String.valueOf(result0));
            }
        });

    }
}